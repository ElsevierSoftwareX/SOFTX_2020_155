#!/bin/sh
# WARNING: This file was auto-generated. Do not edit!
CC='gcc -O2'
LD='gcc -s'
